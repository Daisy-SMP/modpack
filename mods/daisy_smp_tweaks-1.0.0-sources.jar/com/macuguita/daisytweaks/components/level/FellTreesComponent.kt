@file:Suppress("UnstableApiUsage")

package com.macuguita.daisytweaks.components.level

import com.macuguita.daisytweaks.DaisySMPTweaks
import com.mojang.serialization.Codec
import com.mojang.serialization.codecs.RecordCodecBuilder
import net.minecraft.core.BlockPos
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.item.ItemEntity
import net.minecraft.world.item.ItemStack
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.storage.ValueInput
import net.minecraft.world.level.storage.ValueOutput
import org.ladysnake.cca.api.v3.component.tick.ServerTickingComponent
import java.util.function.Function
import java.util.stream.Collectors

class FellTreesComponent(private val obj: Level) : ServerTickingComponent {
    private val treesToCut: MutableList<Tree> = ArrayList<Tree>()

    override fun readData(input: ValueInput) {
        treesToCut.clear()
        for (tree in input.read("TreesToCut", Tree.CODEC.listOf()).orElse(mutableListOf())!!) {
            treesToCut.add(
                Tree(
                    ArrayList(tree.logs),
                    ArrayList(tree.drops),
                    tree.originalPos,
                    tree.stack.copy()
                )
            )
        }
    }

    override fun writeData(output: ValueOutput) {
        output.store("TreesToCut", Tree.CODEC.listOf(), treesToCut)
    }

    override fun serverTick() {
        for (i in treesToCut.indices.reversed()) {
            val tree = treesToCut[i]
            if (tree.logs.isEmpty()) {
                DaisySMPTweaks.mergeItemEntities(
                    tree.drops.stream().map { drop: ItemStack? ->
                        ItemEntity(
                            obj,
                            tree.originalPos.x + 0.5,
                            tree.originalPos.y + 0.5,
                            tree.originalPos.z + 0.5,
                            drop!!
                        )
                    }.collect(Collectors.toList())
                ).forEach({ entity: Entity? -> obj.addFreshEntity(entity!!) })
                treesToCut.removeAt(i)
                continue
            }
            val pos = tree.logs.removeLast()
            tree.drops.addAll(
                Block.getDrops(
                    obj.getBlockState(pos),
                    obj as ServerLevel,
                    pos,
                    obj.getBlockEntity(pos),
                    null,
                    tree.stack
                )
            )
            obj.destroyBlock(pos, false)
        }
    }

    fun addTree(tree: Tree?) {
        treesToCut.add(tree!!)
    }

    data class Tree(
        val logs: MutableList<BlockPos>,
        val drops: MutableList<ItemStack?>,
        val originalPos: BlockPos,
        val stack: ItemStack
    ) {
        companion object {
            val CODEC: Codec<Tree> =
                RecordCodecBuilder.create(Function { i ->
                    i.group(
                        BlockPos.CODEC.listOf().fieldOf("logs").forGetter(Tree::logs),
                        ItemStack.CODEC.listOf().fieldOf("drops").forGetter(Tree::drops),
                        BlockPos.CODEC.fieldOf("original_pos").forGetter(Tree::originalPos),
                        ItemStack.CODEC.fieldOf("stack").forGetter(Tree::stack)
                    )
                        .apply(
                            i,
                            { logs, drops, originalPos, stack ->
                                Tree(
                                    logs,
                                    drops,
                                    originalPos,
                                    stack
                                )
                            })
                })

            fun of(logs: MutableList<BlockPos>, originalPos: BlockPos, stack: ItemStack): Tree {
                return Tree(logs, ArrayList(), originalPos, stack.copy())
            }
        }
    }
}
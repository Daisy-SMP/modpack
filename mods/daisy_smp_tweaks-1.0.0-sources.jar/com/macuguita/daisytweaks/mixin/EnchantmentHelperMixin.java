package com.macuguita.daisytweaks.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.macuguita.daisytweaks.DaisySMPTweaksUtils;
import com.macuguita.daisytweaks.power.type.InnateUnbreakingPowerType;
import io.github.apace100.apoli.component.PowerHolderComponent;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import org.apache.commons.lang3.mutable.MutableFloat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EnchantmentHelper.class)
public class EnchantmentHelperMixin {

    @Inject(
            method = "processDurabilityChange",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/enchantment/EnchantmentHelper;runIterationOnItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/enchantment/EnchantmentHelper$EnchantmentVisitor;)V")
    )
    private static void daisy$innateUnbreaking(ServerLevel serverLevel, ItemStack itemStack, int amount, CallbackInfoReturnable<Integer> cir, @Local MutableFloat damage) {
        if (DaisySMPTweaksUtils.cachedPlayer != null) {
            Enchantment unbreaking = serverLevel.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(Enchantments.UNBREAKING).map(Holder.Reference::value).orElse(null);
            if (unbreaking != null) {
                int level = 0;
                for (InnateUnbreakingPowerType powerType : PowerHolderComponent.getPowers(DaisySMPTweaksUtils.cachedPlayer, InnateUnbreakingPowerType.class)) {
                    if (powerType.isActive() && powerType.doesApply(itemStack)) {
                        level += powerType.getLevel();
                    }
                }
                if (level > 0) {
                    unbreaking.modifyDurabilityChange(serverLevel, level, itemStack, damage);
                }
            }
            DaisySMPTweaksUtils.cachedPlayer = null;
        }
    }
}

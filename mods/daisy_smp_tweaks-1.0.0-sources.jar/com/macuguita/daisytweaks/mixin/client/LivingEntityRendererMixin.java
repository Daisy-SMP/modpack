package com.macuguita.daisytweaks.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.macuguita.daisytweaks.reg.DSMPObjects;
import eu.pb4.trinkets.api.TrinketsApi;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {

    @WrapOperation(
            method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getItemBySlot(Lnet/minecraft/world/entity/EquipmentSlot;)Lnet/minecraft/world/item/ItemStack;")
    )
    private ItemStack daisy$customItemRenderer(LivingEntity instance, EquipmentSlot slot, Operation<ItemStack> original) {
        if (TrinketsApi.getAttachment(instance).isEquipped(DSMPObjects.getCOLOR_BLINDNESS_CORRECTION_GOGGLES().get())) {
            return TrinketsApi.getAttachment(instance).getEquipped(itemStack -> itemStack.is(DSMPObjects.getCOLOR_BLINDNESS_CORRECTION_GOGGLES().get())).getFirst().getB();
        } else {
            return original.call(instance, slot);
        }
    }
}

package com.macuguita.daisytweaks.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.macuguita.daisytweaks.power.DSMPPowerTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.PowderSnowBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(PowderSnowBlock.class)
public class PowderSnowBlockMixin {

    @ModifyReturnValue(method = "canEntityWalkOnPowderSnow", at = @At("RETURN"))
    private static boolean daisy$canFallThroughPowderSnowPower(boolean original, @Local(argsOnly = true) Entity entity) {
        return original || DSMPPowerTypes.getCANT_FALL_POWDERED_SNOW().isActive(entity);
    }
}

package com.macuguita.daisytweaks.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.macuguita.daisytweaks.DaisySMPTweaksUtils;
import com.macuguita.daisytweaks.event.ModifyDestroySpeedEvent;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Player.class)
public abstract class PlayerMixin extends Avatar {
    @Shadow
    @Final
    private Inventory inventory;

    protected PlayerMixin(EntityType<? extends LivingEntity> type, Level level) {
        super(type, level);
    }

    @ModifyExpressionValue(method = "getDestroySpeed", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getDestroySpeed(Lnet/minecraft/world/level/block/state/BlockState;)F"))
    private float daisy$modifyDestroySpeed(float original, BlockState state) {
        return original * ModifyDestroySpeedEvent.MULTIPLY_BASE.invoker().modify((Player) (Object) this, inventory.getSelectedItem(), level(), state, DaisySMPTweaksUtils.currentEventDestroyPos);
    }

    @ModifyExpressionValue(method = "getDestroySpeed", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getAttributeValue(Lnet/minecraft/core/Holder;)D", ordinal = 0))
    private double daisy$modifyDestroySpeed(double original, BlockState state) {
        return original + ModifyDestroySpeedEvent.ADD_EFFICIENCY.invoker().modify((Player) (Object) this, inventory.getSelectedItem(), level(), state, DaisySMPTweaksUtils.currentEventDestroyPos);
    }

    @ModifyReturnValue(method = "getDestroySpeed", at = @At("RETURN"))
    private float daisy$modifyDestroySpeedTotal(float original, BlockState state) {
        return original * ModifyDestroySpeedEvent.MULTIPLY_TOTAL.invoker().modify((Player) (Object) this, inventory.getSelectedItem(), level(), state, DaisySMPTweaksUtils.currentEventDestroyPos);
    }
}
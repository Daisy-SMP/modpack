package com.macuguita.daisytweaks.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.macuguita.daisytweaks.power.DSMPPowerTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

@Mixin(ServerLevel.class)
public abstract class ServerLevelMixin {

    @Shadow
    public abstract List<ServerPlayer> getPlayers(Predicate<? super ServerPlayer> selector);

    @ModifyReturnValue(method = "findLightningRod", at = @At("RETURN"))
    private Optional<BlockPos> daisy$powerAttractLightning(Optional<BlockPos> original, @Local(argsOnly = true) BlockPos center) {
        if (original.isPresent()) {
            return original;
        }

        var centerVec = center.getCenter();

        var playerPos = getPlayers(p -> p.position().closerThan(centerVec, 128))
                .stream()
                .filter(p -> DSMPPowerTypes.getLIKELY_TO_BE_HIT_BY_LIGHTNING().isActive(p))
                .min(Comparator.comparingDouble(p -> p.distanceToSqr(centerVec)))
                .map(Entity::blockPosition)
                .orElse(null);

        return Optional.ofNullable(playerPos);
    }
}

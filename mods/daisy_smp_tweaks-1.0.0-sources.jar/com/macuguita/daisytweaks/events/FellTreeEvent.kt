package com.macuguita.daisytweaks.events

import com.macuguita.daisytweaks.DaisySMPTweaks
import com.macuguita.daisytweaks.components.level.FellTreesComponent
import com.macuguita.daisytweaks.event.ModifyDestroySpeedEvent
import com.macuguita.daisytweaks.reg.DSMPBlockTags
import com.macuguita.daisytweaks.reg.DSMPEnchantmentEffectComponentTypes
import com.macuguita.daisytweaks.reg.DSMPLevelComponents
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents
import net.minecraft.core.BlockPos
import net.minecraft.core.Vec3i
import net.minecraft.util.Mth
import net.minecraft.world.entity.EquipmentSlot
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.enchantment.EnchantmentHelper
import net.minecraft.world.level.BlockGetter
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.entity.BlockEntity
import net.minecraft.world.level.block.state.BlockState
import kotlin.math.abs
import kotlin.math.min

object FellTreesEvent {
    val ENTRIES: MutableList<Entry> = mutableListOf()

    fun gatherTree(
        tree: MutableList<BlockPos>,
        level: BlockGetter,
        pos: BlockPos.MutableBlockPos,
        original: Block
    ): MutableList<BlockPos> {
        if (tree.size < DaisySMPTweaks.CONFIG.maxFellTreesBlocks) {
            val (originalX, originalY, originalZ) = listOf(pos.x, pos.y, pos.z)

            for (x in -1..1) {
                for (y in -1..1) {
                    for (z in -1..1) {
                        pos.set(originalX + x, originalY + y, originalZ + z)

                        if (level !is Level || level.worldBorder.isWithinBounds(pos)) {
                            val state = level.getBlockState(pos)
                            if (state.`is`(DSMPBlockTags.FELLABLE) &&
                                !tree.contains(pos) &&
                                state.block == original
                            ) {
                                tree.add(pos.immutable())
                                gatherTree(tree, level, pos, original)
                            }
                        }
                    }
                }
            }
        }
        return tree
    }

    fun isWithinHorizontalBounds(tree: List<BlockPos>): Boolean {
        var minX: Int? = null
        var maxX: Int? = null
        var minZ: Int? = null
        var maxZ: Int? = null

        for (pos in tree) {
            if (minX == null || pos.x < minX) minX = pos.x
            if (maxX == null || pos.x > maxX) maxX = pos.x
            if (minZ == null || pos.z < minZ) minZ = pos.z
            if (maxZ == null || pos.z > maxZ) maxZ = pos.z
        }

        if (minX == null) return false

        return abs(maxX!! - minX) < DaisySMPTweaks.CONFIG.maxFellTreesHorizontalLength &&
                abs(maxZ!! - minZ!!) < DaisySMPTweaks.CONFIG.maxFellTreesHorizontalLength
    }

    fun canActivate(player: Player, stack: ItemStack, state: BlockState): Boolean {
        return !player.isShiftKeyDown &&
                EnchantmentHelper.has(stack, DSMPEnchantmentEffectComponentTypes.FELL_TREES) &&
                state.`is`(DSMPBlockTags.FELLABLE) &&
                player.hasCorrectToolForDrops(state)
    }

    fun isValid(tree: List<BlockPos>, stack: ItemStack): Boolean {
        if (!stack.isDamageableItem || stack.damageValue + tree.size <= stack.maxDamage) {
            return tree.size > 1 &&
                    tree.size <= DaisySMPTweaks.CONFIG.maxFellTreesBlocks &&
                    isWithinHorizontalBounds(tree)
        }
        return false
    }

    class DestroySpeed : ModifyDestroySpeedEvent {
        override fun modify(
            player: Player,
            stack: ItemStack,
            level: Level,
            state: BlockState,
            pos: BlockPos?
        ): Float {
            if (pos != null && canActivate(player, stack, state)) {
                var entry = Entry.get(player)

                if (entry == null) {
                    entry = Entry(
                        player,
                        gatherTree(
                            mutableListOf(),
                            level,
                            BlockPos.MutableBlockPos().set(pos),
                            state.block
                        )
                    )
                    ENTRIES.add(entry)
                }

                if (isValid(entry.tree, stack)) {
                    val fellTreesSpeed = DaisySMPTweaks.getValue(
                        DSMPEnchantmentEffectComponentTypes.FELL_TREES,
                        player.random,
                        stack,
                        0f
                    )

                    return Mth.lerp(
                        min(1f, entry.tree.size / 32f),
                        fellTreesSpeed,
                        fellTreesSpeed * 0.05f
                    )
                }
            }
            return 1f
        }
    }

    class FellTree : PlayerBlockBreakEvents.Before {
        override fun beforeBlockBreak(
            level: Level,
            player: Player,
            pos: BlockPos,
            state: BlockState,
            blockEntity: BlockEntity?
        ): Boolean {
            val stack = player.mainHandItem

            if (canActivate(player, stack, state)) {
                val entry = Entry.get(player)

                if (entry != null && isValid(entry.tree, stack)) {
                    entry.tree.sortByDescending(Vec3i::getY)

                    DSMPLevelComponents.FELL_TREES.get(level)
                        .addTree(FellTreesComponent.Tree.of(entry.tree, pos, stack))

                    ENTRIES.remove(entry)
                    stack.hurtAndBreak(entry.tree.size, player, EquipmentSlot.MAINHAND)

                    return false
                }
            }
            return true
        }
    }

    data class Entry(val player: Player, val tree: MutableList<BlockPos>) {
        companion object {
            fun get(player: Player): Entry? {
                return ENTRIES.firstOrNull { it.player == player }
            }
        }
    }
}
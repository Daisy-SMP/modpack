package com.macuguita.daisytweaks.reg

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import net.minecraft.core.HolderGetter
import net.minecraft.core.HolderSet
import net.minecraft.core.registries.Registries
import net.minecraft.data.worldgen.BootstrapContext
import net.minecraft.resources.Identifier
import net.minecraft.resources.ResourceKey
import net.minecraft.tags.ItemTags
import net.minecraft.world.entity.EquipmentSlotGroup
import net.minecraft.world.item.Item
import net.minecraft.world.item.enchantment.Enchantment
import net.minecraft.world.item.enchantment.LevelBasedValue
import net.minecraft.world.item.enchantment.effects.AddValue

object DSMPEnchantments {

    val LUMBERJACK: ResourceKey<Enchantment> = createKey("lumberjack")

    private fun createKey(id: String): ResourceKey<Enchantment> =
        ResourceKey.create(Registries.ENCHANTMENT, id.id)

    fun create(
        id: Identifier,
        supportedItems: HolderSet<Item>,
        maxLevel: Int,
        group: EquipmentSlotGroup,
        effectsAdder: (Enchantment.Builder) -> (Unit)
    ): Enchantment {
        val builder = Enchantment.enchantment(
            Enchantment.definition(
                supportedItems,
                5,
                maxLevel,
                Enchantment.dynamicCost(10, 10),
                Enchantment.dynamicCost(40, 10),
                2,
                group
            )
        )
        effectsAdder(builder)
        return builder.build(id)
    }

    fun bootstrap(registry: BootstrapContext<Enchantment>) {
        val itemLookup: HolderGetter<Item> = registry.lookup(Registries.ITEM)

        registry.register(
            LUMBERJACK, create(
                LUMBERJACK.identifier(),
                itemLookup.getOrThrow(ItemTags.AXES),
                2,
                EquipmentSlotGroup.MAINHAND,
                { builder ->
                    builder.withSpecialEffect(
                        DSMPEnchantmentEffectComponentTypes.FELL_TREES,
                        AddValue(LevelBasedValue.perLevel(0.25f))
                    )
                })
        )
    }
}
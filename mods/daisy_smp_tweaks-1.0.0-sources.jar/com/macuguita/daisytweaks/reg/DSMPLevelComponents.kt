package com.macuguita.daisytweaks.reg

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import com.macuguita.daisytweaks.components.level.FellTreesComponent
import org.ladysnake.cca.api.v3.component.ComponentRegistry
import org.ladysnake.cca.api.v8.level.LevelComponentFactoryRegistry
import org.ladysnake.cca.api.v8.level.LevelComponentInitializer

object DSMPLevelComponents : LevelComponentInitializer {

    val FELL_TREES = ComponentRegistry.getOrCreate("fell_trees".id, FellTreesComponent::class.java)

    override fun registerLevelComponentFactories(registry: LevelComponentFactoryRegistry) {
        registry.register(FELL_TREES, ::FellTreesComponent)
    }
}
package com.macuguita.daisytweaks.reg

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import net.minecraft.core.Registry
import net.minecraft.core.component.DataComponentType
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.resources.Identifier
import net.minecraft.world.item.enchantment.effects.EnchantmentValueEffect

object DSMPEnchantmentEffectComponentTypes {

    val FELL_TREES = register("fell_trees".id, { b -> b.persistent(EnchantmentValueEffect.CODEC) })

    private fun <T : Any> register(
        id: Identifier,
        builder: (DataComponentType.Builder<T>) -> DataComponentType.Builder<T>
    ): DataComponentType<T> {
        return Registry.register(
            BuiltInRegistries.ENCHANTMENT_EFFECT_COMPONENT_TYPE,
            id,
            builder(DataComponentType.builder()).build()
        )
    }

    fun init() {}
}

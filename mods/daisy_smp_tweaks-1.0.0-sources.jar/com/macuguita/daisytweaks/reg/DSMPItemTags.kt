package com.macuguita.daisytweaks.reg

import eu.pb4.trinkets.impl.TrinketsMain
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.resources.Identifier
import net.minecraft.tags.TagKey

object DSMPItemTags {

    val TRINKETS_FACE =
        TagKey.create(BuiltInRegistries.ITEM.key(), Identifier.fromNamespaceAndPath(TrinketsMain.MOD_ID, "head/face"))
}
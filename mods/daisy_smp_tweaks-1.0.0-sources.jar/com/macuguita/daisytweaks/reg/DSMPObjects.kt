package com.macuguita.daisytweaks.reg

import com.macuguita.daisytweaks.DaisySMPTweaks
import com.macuguita.daisytweaks.DaisySMPTweaks.id
import com.macuguita.daisytweaks.block.InvisibleLightBlock
import com.macuguita.lib.reg.GuitaRegistries
import com.macuguita.lib.reg.GuitaRegistry
import com.macuguita.lib.reg.GuitaRegistryEntry
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.resources.ResourceKey
import net.minecraft.world.item.BlockItem
import net.minecraft.world.item.Item
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraft.world.level.material.PushReaction

object DSMPObjects {

    val ITEMS = GuitaRegistries.create(BuiltInRegistries.ITEM, DaisySMPTweaks.MOD_ID)
    val BLOCKS = GuitaRegistries.create(BuiltInRegistries.BLOCK, DaisySMPTweaks.MOD_ID)

    @JvmStatic
    val COLOR_BLINDNESS_CORRECTION_GOGGLES =
        registerItem("color_blindness_correction_goggles", ::Item, Item.Properties())
    @JvmStatic
    val FIREFLY_POOP = registerBlockWithItem("firefly_poop", ::InvisibleLightBlock, BlockBehaviour.Properties.of()
        .lightLevel { 15 }.pushReaction(PushReaction.DESTROY).noCollision().replaceable())

    fun registerBlockWithItem(
        name: String,
        block: (BlockBehaviour.Properties) -> (Block),
        blockProperties: BlockBehaviour.Properties = BlockBehaviour.Properties.of(),
        blockRegistry: GuitaRegistry<Block> = BLOCKS,
        itemRegistry: GuitaRegistry<Item> = ITEMS,
    ): GuitaRegistryEntry<Block> {
        val toReturn = registerBlock(name, block, blockProperties, blockRegistry)
        registerItem(name, { BlockItem(toReturn.get(), it) }, Item.Properties().useItemDescriptionPrefix(), itemRegistry)
        return toReturn
    }

    fun registerBlock(
        name: String,
        block: (BlockBehaviour.Properties) -> (Block),
        blockProperties: BlockBehaviour.Properties = BlockBehaviour.Properties.of(),
        registry: GuitaRegistry<Block> = BLOCKS,
    ): GuitaRegistryEntry<Block> = registry.register(name) {
        block(
            blockProperties.setId(
                ResourceKey.create(
                    BuiltInRegistries.BLOCK.key(),
                    name.id
                )
            )
        )
    }

    fun registerItem(
        name: String,
        item: (Item.Properties) -> (Item),
        itemProperties: Item.Properties = Item.Properties(),
        registry: GuitaRegistry<Item> = ITEMS,
    ): GuitaRegistryEntry<Item> = registry.register(name) {
        item(
            itemProperties.setId(
                ResourceKey.create(
                    BuiltInRegistries.ITEM.key(),
                    name.id
                )
            )
        )
    }

    fun init() {
        ITEMS.init()
        BLOCKS.init()
    }
}
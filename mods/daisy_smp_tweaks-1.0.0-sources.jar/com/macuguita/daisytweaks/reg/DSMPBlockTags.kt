package com.macuguita.daisytweaks.reg

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import net.minecraft.core.registries.Registries
import net.minecraft.tags.TagKey
import net.minecraft.world.level.block.Block

object DSMPBlockTags {

    val FELLABLE: TagKey<Block> = TagKey.create(Registries.BLOCK, "fellable".id)
}
package com.macuguita.daisytweaks.power

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import com.macuguita.daisytweaks.power.type.InnateUnbreakingPowerType
import com.macuguita.daisytweaks.power.type.ModifyItemAttributesPowerType
import io.github.apace100.apoli.power.Power
import io.github.apace100.apoli.power.PowerTypeReference
import io.github.apace100.apoli.power.factory.PowerFactory
import io.github.apace100.apoli.power.factory.PowerFactorySupplier
import io.github.apace100.apoli.power.legacy.ModifyBehaviorPower
import io.github.apace100.apoli.registry.ApoliRegistries
import net.minecraft.core.Registry

object DSMPPowerTypes {
    @JvmStatic
    val LIKELY_TO_BE_HIT_BY_LIGHTNING = PowerTypeReference<Power>("likely_to_be_hit_by_lightning".id)

    @JvmStatic
    val CANT_FALL_POWDERED_SNOW = PowerTypeReference<Power>("cant_fall_powdered_snow".id)

    fun register() {
        register(InnateUnbreakingPowerType.createFactory())
        register(ModifyItemAttributesPowerType.createFactory())
    }

    private fun register(powerFactory: PowerFactory<*>) {
        Registry.register(ApoliRegistries.POWER_FACTORY, powerFactory.serializerId, powerFactory)
    }

    private fun register(factorySupplier: PowerFactorySupplier<*>) {
        register(factorySupplier.createFactory())
    }
}
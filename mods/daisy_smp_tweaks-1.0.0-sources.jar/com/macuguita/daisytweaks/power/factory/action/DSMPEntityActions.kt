package com.macuguita.daisytweaks.power.factory.action

import com.macuguita.daisytweaks.power.factory.action.entity.BlockRaycastActionEntityActionType
import io.github.apace100.apoli.power.factory.action.ActionFactory
import io.github.apace100.apoli.registry.ApoliRegistries
import net.minecraft.core.Registry
import net.minecraft.world.entity.Entity

object DSMPEntityActions {

    fun register() {
        register(BlockRaycastActionEntityActionType.getFactory())
    }

    private fun register(conditionFactory: ActionFactory<Entity>) {
        Registry.register(
            ApoliRegistries.ENTITY_ACTION,
            conditionFactory.serializerId,
            conditionFactory
        )
    }
}
package com.macuguita.daisytweaks.power.factory.action.entity

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import io.github.apace100.apoli.data.ApoliDataTypes
import io.github.apace100.apoli.power.factory.action.ActionFactory
import io.github.apace100.apoli.power.factory.condition.ConditionFactory
import io.github.apace100.calio.data.SerializableData
import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.player.Player
import net.minecraft.world.level.ClipContext
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.state.pattern.BlockInWorld
import net.minecraft.world.phys.HitResult
import net.minecraft.world.phys.Vec3

object BlockRaycastActionEntityActionType {

    fun action(data: SerializableData.Instance, entity: Entity) {
        val blockCondition = data.get<ConditionFactory<BlockInWorld>.Instance>("block_condition")
        val blockAction =
            data.get<ActionFactory<org.apache.commons.lang3.tuple.Triple<Level, BlockPos, Direction>>.Instance>("block_action")
        val entityAction = data.get<ActionFactory<Entity>.Instance>("entity_action")

        if (entity !is Player) return

        val origin = Vec3(entity.x, entity.eyeY, entity.z)
        val direction = entity.getViewVector(1f)
        val target = origin.add(direction.scale(entity.blockInteractionRange()))

        val result = entity.level().clip(
            ClipContext(
                origin,
                target,
                ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE,
                entity
            )
        )

        if (result.type == HitResult.Type.MISS) return

        val block = BlockInWorld(entity.level(), result.blockPos, true)

        if (blockCondition != null && !blockCondition.test(block)) return

        blockAction.accept(
            org.apache.commons.lang3.tuple.Triple.of(
                entity.level(),
                result.blockPos,
                result.direction
            )
        )

        entityAction.accept(entity)
    }

    fun getFactory(): ActionFactory<Entity> {
        return ActionFactory<Entity>(
            "block_raycast_action".id,
            SerializableData()
                .add("block_condition", ApoliDataTypes.BLOCK_CONDITION)
                .add("block_action", ApoliDataTypes.BLOCK_ACTION)
                .add("entity_action", ApoliDataTypes.ENTITY_ACTION),
            BlockRaycastActionEntityActionType::action
        )
    }
}
package com.macuguita.daisytweaks.power.factory.condition

import com.macuguita.daisytweaks.power.factory.condition.damage.CrossbowProjectileConditionType
import com.macuguita.daisytweaks.power.factory.condition.entity.EquippedTrinketConditionType
import io.github.apace100.apoli.power.factory.condition.ConditionFactory
import io.github.apace100.apoli.registry.ApoliRegistries
import net.minecraft.core.Registry
import net.minecraft.util.Tuple
import net.minecraft.world.damagesource.DamageSource
import net.minecraft.world.entity.Entity

object DSMPDamageConditions {

    fun register() {
        register(CrossbowProjectileConditionType.getFactory())
    }

    private fun register(conditionFactory: ConditionFactory<Tuple<DamageSource, Float>>) {
        Registry.register(
            ApoliRegistries.DAMAGE_CONDITION,
            conditionFactory.serializerId,
            conditionFactory
        )
    }
}
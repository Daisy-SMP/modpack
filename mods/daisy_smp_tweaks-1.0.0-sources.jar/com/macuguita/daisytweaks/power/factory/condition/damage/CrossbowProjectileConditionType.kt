package com.macuguita.daisytweaks.power.factory.condition.damage

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import com.macuguita.daisytweaks.data.TrinketSlotKey
import eu.pb4.trinkets.api.TrinketsApi
import io.github.apace100.apoli.power.factory.condition.ConditionFactory
import io.github.apace100.apoli.power.factory.condition.DamageConditions
import io.github.apace100.calio.data.SerializableData
import net.minecraft.util.Tuple
import net.minecraft.world.damagesource.DamageSource
import net.minecraft.world.damagesource.DamageType
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.projectile.Projectile
import net.minecraft.world.item.CrossbowItem
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items

object CrossbowProjectileConditionType {

    fun action(data: SerializableData.Instance, damageType: Tuple<DamageSource, Float>): Boolean {
        val projectile = damageType.a.entity

        if (projectile !is Projectile) return false

        val owner = projectile.owner
        if (owner !is LivingEntity) return false

        val mainHand = owner.mainHandItem
        val offHand = owner.offhandItem

        return mainHand.`is`(Items.CROSSBOW) || offHand.`is`(Items.CROSSBOW)
    }

    fun getFactory() =
        ConditionFactory(
            "crossbow_projectile".id,
            SerializableData(),
            CrossbowProjectileConditionType::action
        )
}
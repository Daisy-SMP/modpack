package com.macuguita.daisytweaks.power.factory.condition.entity

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import com.macuguita.daisytweaks.data.DSMPSerializableDataTypes
import com.macuguita.daisytweaks.data.TrinketSlotKey
import eu.pb4.trinkets.api.TrinketsApi
import io.github.apace100.apoli.data.ApoliDataTypes
import io.github.apace100.apoli.power.factory.condition.ConditionFactory
import io.github.apace100.calio.data.SerializableData
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.item.ItemStack

object EquippedTrinketConditionType {

    fun action(data: SerializableData.Instance, entity: Entity): Boolean {
        if (entity !is LivingEntity) return false

        val key = data.get<TrinketSlotKey>("trinket_slot")
        val itemCondition =
            data.get<ConditionFactory<ItemStack>.Instance>("item_condition")

        val attachment = TrinketsApi.getAttachment(entity)
        val inventory = attachment.inventory

        val group = inventory[key.group] ?: return false
        val slotList = group[key.slot] ?: return false

        return slotList.any { slot ->
            itemCondition.test(slot)
        }
    }

    fun getFactory(): ConditionFactory<Entity> {
        return ConditionFactory<Entity>(
            "equipped_trinket".id,
            SerializableData()
                .add("trinket_slot", DSMPSerializableDataTypes.TRINKET_SLOT)
                .add("item_condition", ApoliDataTypes.ITEM_CONDITION),
            EquippedTrinketConditionType::action
        )
    }
}
package com.macuguita.daisytweaks.power.factory.condition

import com.macuguita.daisytweaks.power.factory.condition.entity.EquippedTrinketConditionType
import io.github.apace100.apoli.power.factory.condition.ConditionFactory
import io.github.apace100.apoli.registry.ApoliRegistries
import net.minecraft.core.Registry
import net.minecraft.world.entity.Entity

object DSMPEntityConditions {

    fun register() {
        register(EquippedTrinketConditionType.getFactory())
    }

    private fun register(conditionFactory: ConditionFactory<Entity>) {
        Registry.register(
            ApoliRegistries.ENTITY_CONDITION,
            conditionFactory.serializerId,
            conditionFactory
        )
    }
}
package com.macuguita.daisytweaks.power.type

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import io.github.apace100.apoli.data.ApoliDataTypes
import io.github.apace100.apoli.power.AttributePower
import io.github.apace100.apoli.power.PowerType
import io.github.apace100.apoli.power.factory.PowerFactory
import io.github.apace100.apoli.util.AttributedEntityAttributeModifier
import io.github.apace100.calio.data.SerializableData
import io.github.apace100.calio.data.SerializableDataTypes
import net.minecraft.world.entity.EquipmentSlot
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.item.ItemStack
import java.util.function.BiFunction
import java.util.function.Predicate

class ModifyItemAttributesPowerType(
    type: PowerType<*>,
    entity: LivingEntity?,
    val slot: EquipmentSlot,
    private val itemCondition: Predicate<ItemStack>,
    private val tickRate: Int,
    updateHealth: Boolean,
) : AttributePower(type, entity, updateHealth) {

    init {
        setTicking(true)
    }

    override fun tick() {
        if (entity.tickCount % tickRate != 0) {
            return
        }
        for (slot in EquipmentSlot.entries) {
            if (this.slot == slot) {
                if (doesApply(entity.getItemBySlot(slot))) {
                    onAdded()
                } else {
                    onRemoved()
                }
            }
        }
    }

    fun doesApply(stack: ItemStack): Boolean {
        return itemCondition.test( stack)
    }

    companion object {
        fun createFactory(): PowerFactory<ModifyItemAttributesPowerType> =
            PowerFactory(
                "modify_item_attributes".id,
                SerializableData()
                    .add("equipment_slot", SerializableDataTypes.EQUIPMENT_SLOT)
                    .add("item_condition", ApoliDataTypes.ITEM_CONDITION, null)
                    .add("tick_rate", SerializableDataTypes.INT, 20)
                    .add("update_health", SerializableDataTypes.BOOLEAN, true)
                    .add("modifier", ApoliDataTypes.ATTRIBUTED_ATTRIBUTE_MODIFIER, null)
                    .add("modifiers", ApoliDataTypes.ATTRIBUTED_ATTRIBUTE_MODIFIERS, null)
            ) { data ->
                BiFunction { type, entity: LivingEntity? ->
                    ModifyItemAttributesPowerType(
                        type,
                        entity,
                        data.get("equipment_slot"),
                        data.get("item_condition"),
                        data.getInt("tick_rate"),
                        data.getBoolean("update_health")
                    )
                }
            }
    }
}
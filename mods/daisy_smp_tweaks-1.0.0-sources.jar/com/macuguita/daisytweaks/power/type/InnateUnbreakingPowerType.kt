package com.macuguita.daisytweaks.power.type

import com.macuguita.daisytweaks.DaisySMPTweaks.id
import io.github.apace100.apoli.data.ApoliDataTypes
import io.github.apace100.apoli.power.Power
import io.github.apace100.apoli.power.PowerType
import io.github.apace100.apoli.power.factory.PowerFactory
import io.github.apace100.calio.data.SerializableData
import io.github.apace100.calio.data.SerializableDataTypes
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.item.ItemStack
import java.util.function.BiFunction
import java.util.function.Predicate

class InnateUnbreakingPowerType(
    type: PowerType<*>,
    entity: LivingEntity?,
    private val itemCondition: Predicate<ItemStack>,
    private val level: Int,
) : Power(type, entity) {

    fun doesApply(item: ItemStack) = !item.isEmpty && itemCondition.test(item)

    fun getLevel() = level

    companion object {
        fun createFactory(): PowerFactory<InnateUnbreakingPowerType> =
            PowerFactory(
                "innate_unbreaking".id,
                SerializableData()
                    .add("item_condition", ApoliDataTypes.ITEM_CONDITION)
                    .add("level", SerializableDataTypes.INT)
            ) { data ->
                BiFunction { type: PowerType<InnateUnbreakingPowerType>, entity: LivingEntity? ->
                    InnateUnbreakingPowerType(
                        type,
                        entity,
                        data.get("item_condition"),
                        data.get("level")
                    )
                }
            }
    }
}
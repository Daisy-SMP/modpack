package com.macuguita.daisytweaks

import com.google.common.reflect.Reflection
import com.macuguita.daisytweaks.event.ModifyDestroySpeedEvent
import com.macuguita.daisytweaks.events.FellTreesEvent
import com.macuguita.daisytweaks.power.DSMPPowerTypes
import com.macuguita.daisytweaks.power.factory.action.DSMPEntityActions
import com.macuguita.daisytweaks.power.factory.condition.DSMPDamageConditions
import com.macuguita.daisytweaks.power.factory.condition.DSMPEntityConditions
import com.macuguita.daisytweaks.reg.DSMPEnchantmentEffectComponentTypes
import com.macuguita.daisytweaks.reg.DSMPEnchantments
import com.macuguita.daisytweaks.reg.DSMPObjects
import folk.sisby.kaleido.api.WrappedConfig
import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents
import net.fabricmc.fabric.api.loot.v3.LootTableEvents
import net.fabricmc.loader.api.FabricLoader
import net.minecraft.client.Minecraft
import net.minecraft.core.component.DataComponentType
import net.minecraft.core.registries.Registries
import net.minecraft.resources.Identifier
import net.minecraft.resources.ResourceKey
import net.minecraft.util.RandomSource
import net.minecraft.world.entity.item.ItemEntity
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.world.item.enchantment.EnchantmentHelper
import net.minecraft.world.item.enchantment.effects.EnchantmentValueEffect
import net.minecraft.world.level.storage.loot.LootPool
import net.minecraft.world.level.storage.loot.entries.EmptyLootItem
import net.minecraft.world.level.storage.loot.entries.LootItem
import net.minecraft.world.level.storage.loot.functions.SetEnchantmentsFunction
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue
import org.apache.commons.lang3.mutable.MutableFloat
import org.slf4j.LoggerFactory


object DaisySMPTweaks : ModInitializer {
    val MOD_ID = "daisy_smp_tweaks"
    val LOGGER = LoggerFactory.getLogger(MOD_ID)
    val CONFIG =
        WrappedConfig.createToml(FabricLoader.getInstance().configDir, "", MOD_ID, DaisySMPTweaksConfig::class.java)

    private val LUMBERJACK_LOOT_TABLES = listOf(
        Identifier.withDefaultNamespace("chests/village/village_taiga_house").lootTable,
        Identifier.withDefaultNamespace("chests/village/village_toolsmithe").lootTable,
        Identifier.withDefaultNamespace("chests/pillager_outpost").lootTable,
        Identifier.withDefaultNamespace("chests/woodland_mansion").lootTable,
    )

    private val COLOR_BLINDNESS_GOGGLES_LOOT_TABLES = listOf(
        Identifier.withDefaultNamespace("chests/woodland_mansion").lootTable,
        Identifier.withDefaultNamespace("chests/stronghold_library").lootTable,
    )

    override fun onInitialize() {
        DSMPObjects.init()
        DSMPEnchantmentEffectComponentTypes.init()
        DSMPDamageConditions.register()
        DSMPEntityConditions.register()
        DSMPEntityActions.register()
        DSMPPowerTypes.register()

        ModifyDestroySpeedEvent.MULTIPLY_TOTAL.register(FellTreesEvent.DestroySpeed())
        PlayerBlockBreakEvents.BEFORE.register(FellTreesEvent.FellTree())

        ServerEntityEvents.EQUIPMENT_CHANGE.register { entity, slot, oldStack, newStack ->
            if (entity is Player && entity.isLocalPlayer) return@register
            if (newStack.`is`(Items.CREEPER_HEAD)) {
                Minecraft.getInstance().gameRenderer.setPostEffect("red_green_cb".id)
            } else if (oldStack.`is`(Items.CREEPER_HEAD)) {
                Minecraft.getInstance().gameRenderer.clearPostEffect()
            }
        }

        LootTableEvents.MODIFY.register { key, builder, _, provider ->
            if (LUMBERJACK_LOOT_TABLES.contains(key)) {
                val enchantments = provider.lookupOrThrow(Registries.ENCHANTMENT)

                val poolBuilder = LootPool.lootPool()
                    .setRolls(ConstantValue.exactly(1f))
                    .add(EmptyLootItem.emptyItem().setWeight(3))
                    .add(
                        LootItem.lootTableItem(Items.ENCHANTED_BOOK).setWeight(1)
                            .apply(
                                SetEnchantmentsFunction.Builder().withEnchantment(
                                    enchantments.getOrThrow(DSMPEnchantments.LUMBERJACK),
                                    ConstantValue.exactly(1.0f)
                                )
                            )
                    )
                builder.withPool(poolBuilder)
            }
            if (COLOR_BLINDNESS_GOGGLES_LOOT_TABLES.contains(key)) {
                val poolBuilder = LootPool.lootPool()
                    .setRolls(ConstantValue.exactly(1f))
                    .add(EmptyLootItem.emptyItem().setWeight(9))
                    .add(
                        LootItem.lootTableItem(DSMPObjects.COLOR_BLINDNESS_CORRECTION_GOGGLES.get())
                    )
                builder.withPool(poolBuilder)
            }
        }
    }

    val String.id
        get() = Identifier.fromNamespaceAndPath(MOD_ID, this)

    val Identifier.lootTable
        get() = ResourceKey.create(Registries.LOOT_TABLE, this)

    fun getValue(
        component: DataComponentType<EnchantmentValueEffect>,
        random: RandomSource,
        stack: ItemStack,
        base: Float
    ): Float {
        val mutableFloat = MutableFloat(base)
        EnchantmentHelper.runIterationOnItem(
            stack
        ) { enchantment, level ->
            enchantment.value().modifyUnfilteredValue(component, random, level, mutableFloat)
        }
        return mutableFloat.toFloat()
    }

    fun mergeItemEntities(drops: MutableList<ItemEntity>): MutableList<ItemEntity> {
        for (i in drops.indices.reversed()) {
            if (i < drops.size - 1) {
                val itemEntity = drops[i]
                val other = drops[i + 1]
                itemEntity.tryToMerge(other)
                if (itemEntity.item.isEmpty) {
                    drops.removeAt(i)
                }
                if (other.item.isEmpty) {
                    drops.removeAt(i + 1)
                }
            }
        }
        return drops
    }
}
package com.macuguita.daisytweaks

import folk.sisby.kaleido.api.WrappedConfig

class DaisySMPTweaksConfig : WrappedConfig() {
    var maxFellTreesBlocks: Int = 1024
    var maxFellTreesHorizontalLength: Int = 11
}
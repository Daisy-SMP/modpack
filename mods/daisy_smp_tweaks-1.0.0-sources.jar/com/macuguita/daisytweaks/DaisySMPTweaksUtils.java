package com.macuguita.daisytweaks;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;

public class DaisySMPTweaksUtils {
    public static BlockPos currentEventDestroyPos;
    public static ServerPlayer cachedPlayer;
}

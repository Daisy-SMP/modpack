package com.macuguita.daisytweaks.data

import io.github.apace100.calio.data.SerializableData
import io.github.apace100.calio.data.SerializableDataType
import io.github.apace100.calio.data.SerializableDataTypes


object DSMPSerializableDataTypes {

    val TRINKET_SLOT = SerializableDataType.compound(
        TrinketSlotKey::class.java,
        SerializableData()
            .add("group", SerializableDataTypes.STRING)
            .add("slot", SerializableDataTypes.STRING),

        { instance ->
            TrinketSlotKey(
                instance.getString("group"),
                instance.getString("slot")
            )
        },

        { serializableData, key: TrinketSlotKey ->
            val inst = serializableData.Instance()
            inst.set("group", key.group)
            inst.set("slot", key.slot)
            return@compound inst
        }
    )
}
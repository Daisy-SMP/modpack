package com.macuguita.daisytweaks.data

data class TrinketSlotKey(val group: String, val slot: String)

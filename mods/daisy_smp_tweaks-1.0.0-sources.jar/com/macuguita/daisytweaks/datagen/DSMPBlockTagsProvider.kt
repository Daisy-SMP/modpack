package com.macuguita.daisytweaks.datagen

import com.macuguita.daisytweaks.reg.DSMPBlockTags
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagsProvider
import net.minecraft.core.HolderLookup
import net.minecraft.tags.BlockTags
import net.minecraft.world.level.block.Blocks
import java.util.concurrent.CompletableFuture

class DSMPBlockTagsProvider(
    output: FabricPackOutput,
    registryLookupFuture: CompletableFuture<HolderLookup.Provider>
) : FabricTagsProvider.BlockTagsProvider(output, registryLookupFuture) {

    override fun addTags(registries: HolderLookup.Provider) {
        valueLookupBuilder(DSMPBlockTags.FELLABLE)
            .forceAddTag(BlockTags.LOGS)
            .add(Blocks.MANGROVE_ROOTS)
    }
}
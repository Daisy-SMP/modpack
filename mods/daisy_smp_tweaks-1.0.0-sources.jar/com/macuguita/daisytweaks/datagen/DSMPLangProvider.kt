package com.macuguita.daisytweaks.datagen

import com.macuguita.daisytweaks.reg.DSMPEnchantments
import com.macuguita.daisytweaks.reg.DSMPObjects
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider
import net.minecraft.core.HolderLookup
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.resources.ResourceKey
import net.minecraft.world.item.Item
import net.minecraft.world.item.enchantment.Enchantment
import net.minecraft.world.level.block.Block
import java.util.*
import java.util.concurrent.CompletableFuture

class DSMPLangProvider(
    output: FabricPackOutput,
    registryLookupFuture: CompletableFuture<HolderLookup.Provider>
) : FabricLanguageProvider(output, "en_us", registryLookupFuture) {
    override fun generateTranslations(
        registryLookup: HolderLookup.Provider,
        translationBuilder: TranslationBuilder
    ) {
        DSMPObjects.ITEMS.entries.forEach { translationBuilder.generateItemTranslations(it.get()) }

        translationBuilder.generateEnchantmentTranslations(DSMPEnchantments.LUMBERJACK)
        translationBuilder.generateEnchantmentDescriptionTranslations(
            DSMPEnchantments.LUMBERJACK,
            "Allows you to chop a tree down in one blow."
        )
    }

    private fun capitalizeString(string: String): String {
        val chars = string.lowercase(Locale.getDefault()).toCharArray()
        var found = false
        for (i in chars.indices) {
            if (!found && Character.isLetter(chars[i])) {
                chars[i] = chars[i].uppercaseChar()
                found = true
            } else if (Character.isWhitespace(chars[i]) || chars[i] == '.' || chars[i] == '\'') {
                found = false
            }
        }
        return String(chars)
    }

    private fun TranslationBuilder.generateBlockTranslations(block: Block) {
        val temp = capitalizeString(BuiltInRegistries.BLOCK.getKey(block).path.replace("_", " "))
        this.add(block, temp)
    }

    private fun TranslationBuilder.generateItemTranslations(item: Item) {
        val temp = capitalizeString(BuiltInRegistries.ITEM.getKey(item).path.replace("_", " "))
        this.add(item, temp)
    }

    private fun TranslationBuilder.generateEnchantmentTranslations(enchantment: ResourceKey<Enchantment>) {
        val temp: String = capitalizeString(enchantment.identifier().path.replace("_", " "))
        this.add(
            "enchantment." + enchantment.identifier().namespace + "." + enchantment.identifier().path, temp
        )
    }

    private fun TranslationBuilder.generateEnchantmentDescriptionTranslations(
        enchantment: ResourceKey<Enchantment>,
        description: String
    ) {
        val id = enchantment.identifier()
        this.add("enchantment." + id.namespace + "." + id.path + ".desc", description)
    }
}
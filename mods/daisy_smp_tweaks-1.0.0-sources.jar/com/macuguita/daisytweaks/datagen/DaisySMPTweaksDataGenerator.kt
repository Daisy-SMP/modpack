package com.macuguita.daisytweaks.datagen

import com.macuguita.daisytweaks.reg.DSMPEnchantments
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider
import net.minecraft.core.HolderLookup
import net.minecraft.core.RegistrySetBuilder
import net.minecraft.core.registries.Registries
import java.util.concurrent.CompletableFuture

object DaisySMPTweaksDataGenerator : DataGeneratorEntrypoint {
    override fun onInitializeDataGenerator(fabricDataGenerator: FabricDataGenerator) {
        val pack = fabricDataGenerator.createPack()

        pack.addProvider(::LumberjackProvider)
        pack.addProvider(::DSMPBlockTagsProvider)
        pack.addProvider(::DSMPEnchantmentTagsProvider)
        pack.addProvider(::DSMPItemTagsProvider)
        pack.addProvider(::DSMPLangProvider)
        pack.addProvider(::DSMPModelProvider)
    }

    override fun buildRegistry(registryBuilder: RegistrySetBuilder) {
        registryBuilder.add(Registries.ENCHANTMENT, DSMPEnchantments::bootstrap)
    }

    class LumberjackProvider(
        output: FabricPackOutput,
        registriesFuture: CompletableFuture<HolderLookup.Provider>
    ) : FabricDynamicRegistryProvider(output, registriesFuture) {
        override fun configure(
            registries: HolderLookup.Provider,
            entries: Entries
        ) {
            entries.addAll(registries.lookupOrThrow(Registries.ENCHANTMENT))
        }

        override fun getName(): String = "LumberjackEnchant provider"

    }
}
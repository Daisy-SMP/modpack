package com.macuguita.daisytweaks.datagen

import com.macuguita.daisytweaks.reg.DSMPObjects
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput
import net.minecraft.client.data.models.BlockModelGenerators
import net.minecraft.client.data.models.ItemModelGenerators
import net.minecraft.client.data.models.model.ModelTemplates

class DSMPModelProvider(output: FabricPackOutput) : FabricModelProvider(output) {

    override fun generateBlockStateModels(blockModelGenerators: BlockModelGenerators) {
    }

    override fun generateItemModels(itemModelGenerators: ItemModelGenerators) {
        itemModelGenerators.generateFlatItem(
            DSMPObjects.COLOR_BLINDNESS_CORRECTION_GOGGLES.get(),
            ModelTemplates.FLAT_ITEM
        )
        itemModelGenerators.generateFlatItem(
            DSMPObjects.FIREFLY_POOP.get().asItem(),
            ModelTemplates.FLAT_ITEM
        )
    }
}
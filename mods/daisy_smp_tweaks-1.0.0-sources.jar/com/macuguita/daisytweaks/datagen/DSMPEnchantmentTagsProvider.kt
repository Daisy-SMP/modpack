package com.macuguita.daisytweaks.datagen

import com.macuguita.daisytweaks.reg.DSMPEnchantments
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagsProvider
import net.minecraft.core.HolderLookup
import net.minecraft.core.registries.Registries
import net.minecraft.resources.ResourceKey
import net.minecraft.tags.EnchantmentTags
import net.minecraft.tags.TagKey
import net.minecraft.world.item.enchantment.Enchantment
import java.util.concurrent.CompletableFuture

class DSMPEnchantmentTagsProvider(
    output: FabricPackOutput,
    registryLookupFuture: CompletableFuture<HolderLookup.Provider>
) : FabricTagsProvider<Enchantment>(output, Registries.ENCHANTMENT, registryLookupFuture) {
    override fun addTags(registries: HolderLookup.Provider) {

        fun addLibrarianTrades(common: TagKey<Enchantment>, vararg enchantments: ResourceKey<Enchantment>) =
            builder(common).addAll(listOf(*enchantments))

        addLibrarianTrades(
            EnchantmentTags.TRADES_TAIGA_COMMON,
            DSMPEnchantments.LUMBERJACK
        )
    }

    companion object
}
package com.macuguita.daisytweaks.block

import com.macuguita.daisytweaks.reg.DSMPObjects
import net.minecraft.core.BlockPos
import net.minecraft.world.level.BlockGetter
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.RenderShape
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.phys.shapes.CollisionContext
import net.minecraft.world.phys.shapes.Shapes
import net.minecraft.world.phys.shapes.VoxelShape

class InvisibleLightBlock(properties: Properties) : Block(properties) {

    override fun getShape(state: BlockState, level: BlockGetter, pos: BlockPos, context: CollisionContext): VoxelShape {
        return if (context.isHoldingItem(DSMPObjects.FIREFLY_POOP.get().asItem())) Shapes.block() else Shapes.empty()
    }

    override fun propagatesSkylightDown(state: BlockState): Boolean {
        return state.fluidState.isEmpty
    }

    override fun getRenderShape(state: BlockState): RenderShape {
        return RenderShape.INVISIBLE
    }

    override fun getShadeBrightness(state: BlockState, level: BlockGetter, pos: BlockPos): Float {
        return 1.0f
    }
}
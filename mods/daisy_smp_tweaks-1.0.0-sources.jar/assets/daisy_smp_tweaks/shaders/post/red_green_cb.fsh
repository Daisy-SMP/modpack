#version 330

uniform sampler2D InSampler;

in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0/3.0, 2.0/3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0/3.0, 1.0/3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void main() {
    vec4 color = texture(InSampler, texCoord);

    vec3 hsv = rgb2hsv(color.rgb);
    float hue = hsv.x; // 0.0 - 1.0, where red=0.0/1.0, green=0.333

    // Rotate red hues (around 0.0 and 1.0) toward green (0.333)
    // Define red zone: hues within ~30 degrees (0.083 in 0-1 space) of red
    float redCenter = 0.0;
    float greenHue = 0.333;
    float hueRange = 0.12; // how wide the red zone is

    // Wrap hue so that hues near 1.0 (also red) are treated correctly
    float wrappedHue = hue > 0.5 ? hue - 1.0 : hue;

    // Blend factor: 1.0 at pure red, 0.0 outside the red zone
    float redBlend = 1.0 - smoothstep(0.0, hueRange, abs(wrappedHue));

    // Shift hue toward green
    float newHue = mix(hue, greenHue, redBlend);

    vec3 result = hsv2rgb(vec3(newHue, hsv.y, hsv.z));

    fragColor = vec4(result, color.a);
}